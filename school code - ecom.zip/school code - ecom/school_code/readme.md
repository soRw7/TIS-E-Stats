# TIS: E-STATS WEBSITE
## Intro
This website is made by students of [Tagore International School , Vasant Vihar New Delhi](https://tagoreint.com/vv/V2.0/)  named:

**Soham Panda**
 - [Email](https://cutt.ly/evOXlfa)
 - [Github](https://github.com/SohamPanda345)

**Rohit Chowdhary**:

 - [Github](https://github.com/avacadox21)
 - [Instagram](www.instagram.com/roh_it_chow/)
 - [Email](https://cutt.ly/DvYXEvC)

 
 
 
 **Guided by  Ms.Bhawna Garg** 


## About the website 

This website focuses mainly on the impact of Covis-19 on E-commerce as well as how E-commerce helped the community in these difficult times.

## Contributions
- Homepage by Soham
- Contact page by Rohit
- E-stats/ Learn more page by Rohit
- Design by Soham 
- Readme file by Rohit
- Navbar by Soham
- Footer by Rohit


## Mentions:
- [Font-awesome](https://fontawesome.com/) for svg icons.
- [FormSubmit api ](https://formsubmit.co/) for form submittion in the contact page footer
- [Github](github.com) for hosting the code and website hosting
- [un-Draw](https://undraw.co/illustrations) for svg illustrations.


## Future Plans

If this website wins, we are planning to put it up on netlify or hostinger ot 000webhost.

## Conclusion
In the end I would just like to say we gave in our best and avoided using Javascript because while planning it in the beggining we were planning to use Firebase as well as React js to develop this web application and try making a twitter sort of thing since I was working on one lately. But under the circumstances to avoid using Javascript, we just used css.
Here is the link to the website : [Link](https://avacadox21.github.io/tis-e-stats)


  
